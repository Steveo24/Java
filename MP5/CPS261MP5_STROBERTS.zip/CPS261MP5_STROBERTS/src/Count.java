import java.util.ArrayList;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;


public class Count {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		Random r = new Random();
		for (int i = 0; i < 100; i++)
			list.add(r.nextInt(10));
		Map<Object, Integer> counts = list.parallelStream()
				.collect(Collectors.toConcurrentMap(w -> w, w -> 1, Integer::sum));
		System.out.println(counts);

	}
}
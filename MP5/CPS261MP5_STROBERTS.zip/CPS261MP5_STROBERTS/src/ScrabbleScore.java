import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ScrabbleScore {

	public static void main(String[] args) {

		String[] words = { "Java", "program", "list", "string", "unix", "hours", "syntax", "error" };
		System.out.println("Top three words are: ");
		Stream.of(words).sorted((e1, e2) -> scrapleVal(e2) - scrapleVal(e1)).limit(3)
				.forEach(e -> System.out.println(e + " : " + scrapleVal(e)));

		System.out.print("\nAverage value for words is: ");
		List<Integer> li = new ArrayList<>();
		Stream.of(words).sorted((e1, e2) -> scrapleVal(e2) - scrapleVal(e1)).forEach(e -> li.add(scrapleVal(e)));
		Integer sum = li.stream().collect(Collectors.summingInt(Integer::intValue));

		double average = (double) sum / li.size();

		System.out.println((double) sum / li.size());

		Map<String, Integer> map = new HashMap<>();

		Stream.of(words).sorted((e1, e2) -> scrapleVal(e2) - scrapleVal(e1)).forEach(e -> map.put(e, scrapleVal(e)));

		System.out.print("Words below average:");

		Map<String, Integer> collect = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.filter(x -> x.getValue() < average).collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));

		ArrayList<String> belowAverageList = new ArrayList<>();

		collect.entrySet().stream().sorted(Map.Entry.comparingByValue()).limit(4)
				.forEachOrdered(x -> belowAverageList.add(x.getKey()));
		System.out.println(belowAverageList);

		System.out.print("Words above average:");

		Map<String, Integer> aboveaverageMap = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.filter(x -> x.getValue() > average).collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
		ArrayList<String> aboveAverageList = new ArrayList<>();
		aboveaverageMap.entrySet().stream().sorted(Map.Entry.comparingByValue()).limit(4)
				.forEachOrdered(x -> aboveAverageList.add(x.getKey()));

		System.out.println(aboveAverageList);

	}

	public static int scrapleVal(String word) {
		Map<Character, Integer> letterValues = new HashMap<>();
		letterValues.put('a', 1);
		letterValues.put('b', 3);
		letterValues.put('c', 3);
		letterValues.put('d', 2);
		letterValues.put('e', 1);
		letterValues.put('f', 4);
		letterValues.put('g', 2);
		letterValues.put('h', 4);
		letterValues.put('i', 1);
		letterValues.put('j', 8);
		letterValues.put('k', 5);
		letterValues.put('l', 1);
		letterValues.put('m', 3);
		letterValues.put('n', 1);
		letterValues.put('o', 1);
		letterValues.put('p', 3);
		letterValues.put('q', 10);
		letterValues.put('r', 1);
		letterValues.put('s', 1);
		letterValues.put('t', 1);
		letterValues.put('u', 1);
		letterValues.put('v', 8);
		letterValues.put('w', 4);
		letterValues.put('x', 8);
		letterValues.put('y', 4);
		letterValues.put('z', 10);
		return word.toLowerCase().chars().map(e -> letterValues.get((char) e)).sum();
	}

}
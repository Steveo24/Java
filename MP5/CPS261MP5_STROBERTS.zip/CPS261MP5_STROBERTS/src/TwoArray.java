import java.util.*;

class TwoArray {

	public static void main(String[] args) {

		int[][] number_array = { { 34, 89 }, { 56, 3 }, { 27, 61 }, { 45, 8 }, { 45, 89 } };
		List<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 2; j++) {

				list.add(number_array[i][j]);
			}
		}

		Collections.sort(list);

		System.out.println("The numbers in order:");

		list.stream().distinct().forEach(num -> System.out.print(num + " "));
		System.out.println();
	}
}
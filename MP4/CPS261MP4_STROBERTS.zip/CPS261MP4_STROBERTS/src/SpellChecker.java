import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;
import java.util.*;

public class SpellChecker {
	private HashSet<String> dictionary = new HashSet<String>();

	private TreeSet<String> miss_spelled_words = new TreeSet<String>();

	public SpellChecker() throws FileNotFoundException {
		BufferedReader br = null;
		FileReader fr = null;
		StringTokenizer st;
		try {

			fr = new FileReader("dictionary.txt");
			br = new BufferedReader(fr);

			String line;

			while ((line = br.readLine()) != null) {
				st = new StringTokenizer(line, " \t,.;:-%'\"");
				while (st.hasMoreTokens())
					dictionary.add(st.nextToken());
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}

	public void checkSpelling(String fileName) throws FileNotFoundException {
		System.out.println("======== Spell checking " + fileName + " =========");
		Scanner sc = new Scanner(System.in);
		String option = "";
		String rword = "";

		miss_spelled_words.clear();

		BufferedReader br = null;
		FileReader fr = null;
		StringTokenizer st;
		try {

			fr = new FileReader(fileName);
			br = new BufferedReader(fr);
			String line;
			String word;
			while ((line = br.readLine()) != null) { 
				st = new StringTokenizer(line, " \t,.;:-%'\"");
				while (st.hasMoreTokens()) {
					word = st.nextToken().toLowerCase();
					if (dictionary.contains(word) || miss_spelled_words.contains(word)
							|| (word.charAt(0) > 64 && word.charAt(0) < 91)
							|| (word.charAt(0) > 96 && word.charAt(0) < 123))
						continue;
					else if (Character.toString(word.charAt((word.length()) - 1)).equals("s")) {
						rword = word.substring(0, (word.length()) - 1);
						if (dictionary.contains(word) || miss_spelled_words.contains(word))
							continue;
						else {
							System.out.println(
									"If you want to add" + word + " to dictionary write d or to miss_spelled write m");
							option = sc.next();
							if (option.equals("d"))
								dictionary.add(word);
							else if (option.equals("m"))
								miss_spelled_words.add(word);
							else
								System.out.println("Invalid input hence skipping the word");
						}

					} else {
						System.out.println(
								"If you want to add" + word + " to dictionary write d or to miss_spelled write m");
						option = sc.next();
						if (option.equals("d"))
							dictionary.add(word);
						else if (option.equals("m"))
							miss_spelled_words.add(word);
						else
							System.out.println("Invalid input hence skipping the word");
					}
				}
			}

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (br != null)
					br.close();

				if (fr != null)
					fr.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}

		}

	}

	public void dump_miss_spelled_words() {
		System.out.println(miss_spelled_words);
	}

	public static void main(String[] args) {

		try {
			SpellChecker spellCheck = new SpellChecker();

			for (int i = 0; i < args.length; i++) {
				spellCheck.checkSpelling(args[i]);
				spellCheck.dump_miss_spelled_words();
			}
		} catch (FileNotFoundException e) {
			System.out.println(e);
		}

	}

}
package reading_with_exceptions;

import java.io.File; // required imports for the code
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class ReadingWithExceptions {
	void process(String inputFilename) {

		int number_to_read = 0;
		File file = new File(inputFilename);

		try {
			String outputFilename;
			PrintStream os;
			try (Scanner input = new Scanner(file)) {
				outputFilename = input.next();
				os = new PrintStream(new FileOutputStream(outputFilename));

				if (input.hasNextInt()) {
					number_to_read = input.nextInt();
				} else {
					number_to_read = -1;
				}
				copyNumbers(input, os, number_to_read);
			}
			os.close();
			printToScreen(outputFilename);

		} catch (FileNotFoundException e) {
			System.out.println("Cannot find file: " + e);
		}

	}

	void copyNumbers(Scanner scan, PrintStream ps, int numIntsToRead) {

		if (numIntsToRead < 0) {
			System.out.println("A Message Indicating that reading all the data from the file.");
			while (scan.hasNextInt()) {
				int readNum = scan.nextInt();
				ps.print(readNum);
				ps.print("\n");
				ps.flush();
				System.out.println("\nCompleted Reading the Data.!\n");
			}
		}

		else if (!scan.hasNextInt()) {
			System.out.println("\nNo Data Present in the File to Read.!\n");
			scan.nextLine();
		}

		else {

			for (int i = 0; i < numIntsToRead; i++) {
				if (scan.hasNextInt()) {
					int x = scan.nextInt();
					ps.println(x);
				} else {
					System.out.println("There was a total of " + i + " ints found, and a total of " + numIntsToRead
							+ " specified to read. Reading has completed.");
				}
			}
		}

	}

	public static void main(String[] args) {
		ReadingWithExceptions rwe = new ReadingWithExceptions();
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i] + " \n");
			rwe.process(args[i]);
		}
	}

	private void printToScreen(String filename) {
		Scanner scan = null;

		try {
			FileInputStream fis = new FileInputStream(filename);
			scan = new Scanner(fis);

			System.out.println("Data Present in the Output File is : \n");

			while (scan.hasNextLine()) {
				System.out.println(scan.nextLine());
			}
		} catch (FileNotFoundException e) {
			System.out.println("printToScreen: can't open: " + filename);
		} finally {
			if (scan != null) {
				scan.close();
			}
		}
	}
}
package IO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

class Person {
	//fill in the code
	String name;
	int age;
	public Person(String name, int age)
	{
		this.name = name;
		this.age=age;
	}
	@Override
	public String toString() 
	{
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
	
}

public class MP1Person {
	String fileName;
	ObjectInputStream ois = null;
	ObjectOutputStream oos = null;
	static Scanner kbInput = new Scanner(System.in);

	public MP1Person(String fileName) {
		//fill in the code
		//set fileName
		//construct ObjectInputStream ois using fileName
		//construct ObjectOutputStream oos using fileName
		File pFile = new File("person.dat");
		
		
	}

	public void add() throws FileNotFoundException, IOException {
		oos = new ObjectOutputStream(new FileOutputStream("person.dat", true));

	}

	public void display() throws FileNotFoundException, IOException {
		ois = new ObjectInputStream(new FileInputStream("person.dat"));

	}

	public static void main(String[] args)  {
		MP1Person mp1 = new MP1Person("person.ser");
		try {
			int option = -1;
			while (option != 0) {
				System.out.println("Please choose an option:");
				System.out.println("0: quit");
				System.out.println("1: add");
				System.out.println("2: display");
				option = kbInput.nextInt();
				kbInput.nextLine();
				switch (option) {
				case 0:
					System.out.println("Bye");
					break;					
				case 1:
					//invoke add
					System.out.print("Enter the person's name: ");
					String name = kbInput.nextLine();
					System.out.print("Enter the person's age: ");
					int age = kbInput.nextInt();
					Person p = new Person(name, age);
					add(p);
					continue;
				case 2:
					//invoke display
					display();
					continue;
					
				}

			}
		} finally {
			//close oos
			//close ois
			oos.close();
			ois.close();
		}

	}

}

package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class GUIConverter extends Application {

	TextField fahrenheit = new TextField();
	TextField ceilsius = new TextField();
	Button fToC = new Button("F� to C�");
	Button cToF = new Button("C� to F�");
	
	@Override
	public void start(Stage primaryStage) {
		// fahrenheit to ceilsius: (f-32)*5/9 = c
				//(c*5/9)+32 = f
				GridPane gridPane = new GridPane();
				gridPane.setVgap(5);
				gridPane.setHgap(5);
				gridPane.add(new Label("Fahrenheit:"), 0, 0);
				gridPane.add(fahrenheit, 1, 0);
				gridPane.add(new Label("Ceilsius:"), 0, 1);
				gridPane.add(ceilsius, 1, 1);
				gridPane.add(fToC, 0, 2);
				gridPane.add(cToF, 1, 2);
				fToC.setOnAction(e -> {
					double c;
					c = (Double.parseDouble(fahrenheit.getText())-32)*5/9;
					ceilsius.setText(String.valueOf(c));
				});
				
				cToF.setOnAction(e -> {
					double f;
					f = (Double.parseDouble(ceilsius.getText())*9/5)+32;
					fahrenheit.setText(String.valueOf(f));
				});
				
				Scene scene = new Scene(gridPane, 400, 400);
				
				primaryStage.setScene(scene);
				primaryStage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}
}

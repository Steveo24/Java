package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;


public class HockeyStats extends Application {
	final static String one = "Toronto";
	final static String two = "Boston";
	final static String three = "Los Angeles";
	final static String four = "Detroit";
	final static String five = "Nashville";
	final static String six = "Winnipeg";
	final static String seven = "Tampa Bay";

	public void start(Stage stage) throws Exception {
		final NumberAxis xAxis = new NumberAxis();
		final CategoryAxis yAxis = new CategoryAxis();
		final BarChart<Number, String> bc = new BarChart<Number, String>(xAxis, yAxis);

		xAxis.setTickLabelRotation(90);

		XYChart.Series series1 = new XYChart.Series();
		series1.setName("Count");
		series1.getData().add(new XYChart.Data(286, one));
		series1.getData().add(new XYChart.Data(257, two));
		series1.getData().add(new XYChart.Data(199, three));
		series1.getData().add(new XYChart.Data(224, four));
		series1.getData().add(new XYChart.Data(236, five));
		series1.getData().add(new XYChart.Data(270, six));
		series1.getData().add(new XYChart.Data(319, seven));

		Scene scene = new Scene(bc, 800, 600);
		bc.getData().addAll(series1);
		stage.setScene(scene);
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}

}
module CPS261MP3_STROBERTS {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}

package MP2;

public class MySelectionSort
{
    public static void sort(Student [] list)
    {
        for(int r = 0; r < list.length; r++)
        {
            for(int b = r + 1; b < list.length; b++)
            {
                if (list[r].compareTo(list[b]) == 1)
                {
                    Student temp = list[r];
                    list[r] = list[b];
                    list[b] = temp;
                }
            }
        }
    }
}
package MP2;

import java.util.Arrays;
import java.util.List;

public class Runnable {

	public static void main(String[] args) {
		Student[] students = {new Student(1, "Steve", 3.2),
							  new Student(2, "Joe", 3.1),
							  new Student(3, "David", 3.5),
							  new Student(4, "Jen", 3.2),
							  new Student(5, "Kade", 3.0)};

        for(int i = 0; i < students.length; i++)
        {
            System.out.println(students[i]);
        }

        System.out.println("*****************************");
        MySelectionSort.sort(students);

        for(int i = 0; i < students.length; i++)
        {
            System.out.println(students[i]);
        }
		

	}

}

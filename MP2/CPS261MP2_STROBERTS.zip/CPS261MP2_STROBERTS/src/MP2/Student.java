package MP2;

public class Student implements Comparable<Student> {
	
	private int studentID;
	private String name;
	private double gpa;
    public static int maxStudentID = 0;
	
	public Student(int studentID, String name, double gpa) {
		super();
		this.studentID = studentID;
		this.name = name;
		this.gpa = gpa;
        if (maxStudentID < studentID)
            {
                maxStudentID = studentID;
            }
	}

    //-1 means before, 0 is equal, 1 means after
    public int compareTo(Student that)
    {
        if(that.name.compareTo(this.name) > 0)
        {
            return -1;
        }
        else if (that.name.compareTo(this.name) < 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", name=" + name + ", gpa=" + gpa + "]";
	}
	
	

}

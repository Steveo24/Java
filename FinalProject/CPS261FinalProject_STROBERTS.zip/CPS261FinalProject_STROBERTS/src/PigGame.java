import java.util.Random;
import java.util.Scanner;

public class PigGame {
	public static void main(String[] args) {
		int die;
		int min = 1;
		int max = 6;
		int myScore = 0;
		int compScore = 0;
		int turnScore = 0;
		char choice;
		boolean change = false;
		boolean weHaveAWinner = false;
		Scanner kb = new Scanner(System.in);

		while (true) {// Player turn loop

			while (true) {
				System.out.println("Roll [r], Pass [p], or Quit [q].");
				choice = kb.next().charAt(0);

				if (choice == 'r') {
					die = (int)(Math.random()*(max-min)); // Number generator for die

					if (die > 1) {
						System.out.println("You rolled a " + die + ".");
						turnScore += die;

						if (turnScore + myScore >= 100) {
							System.out.println("You win!");// Winning condition met. 
							break;
						}

						System.out.println("You will add " + turnScore + " points if you pass now. ");
					}

					else {
						System.out.println("You rolled a 1. You lose your points and your turn ends.");
						turnScore = 0;// End turn. 
						break;
					}

				}

				if (choice == 'p') {// End turn by choice. 

					myScore += turnScore;

					System.out.println("Your score is now " + myScore + ".");

					turnScore = 0;

					change = true;

					break;

				} // needs to go to Computer now

				if (choice == 'q') {//Ends game
					System.out.println("Thanks for playing!");
					break;
				} else if (choice > 'r' || choice < 'p') {
					System.out.println("Please select from the choices listed.");
				}

			}

			while (true) {// PC turn loop
				if (myScore > compScore && turnScore < 17 || compScore > myScore && turnScore < 12 || compScore > 84) {
					choice = 'r';
					System.out.println("The PC rolls!");
					if (choice == 'r') {
						die = (int)(Math.random()*(max-min)); // Number generator for die
						if (die > 1) {
							System.out.println("The PC rolls a " + die + ".");
							turnScore += die;
							if (turnScore + compScore >= 100) {// Winning condition met.
								System.out.println("The PC wins!");
								break;
							}

						} else {
							System.out.println("The PC rolls a 1. He loses his points and now it's your turn!");
							turnScore = 0;
							change = false;// End turn.
							break;
						}
					}
				} else {
					System.out.println("The PC chooses to pass.");
					compScore += turnScore;
					choice = 'p';
					turnScore = 0;
					System.out.println("He has " + compScore + " points.");
					System.out.println("The PC now has " + compScore + " points.");
					change = false;// End turn.
					break;
				}
			}
		}
	}

}

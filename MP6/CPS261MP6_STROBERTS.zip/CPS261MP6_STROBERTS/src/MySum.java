import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MySum {
	private int sum = 0;

	public void increaseSum() {
		Thread t = Thread.currentThread();
		String name = "Thread-" + t.getId();
		try {
			Thread.sleep(100);
			this.sum += 1;
			System.out.println(name + " sum is: " + sum);
		} catch (InterruptedException ex) {
			System.out.println(ex.getMessage());
		}
	}

	public static void main(String[] args) throws InterruptedException {
		ExecutorService executorService = Executors.newFixedThreadPool(100);
		MySum mySum = new MySum();
		for (int i = 0; i < 100; i++) {
			executorService.submit(() -> mySum.increaseSum());
		}
		executorService.shutdown();
		executorService.awaitTermination(60, TimeUnit.SECONDS);

	}
}

//public class MySum {
//	private int sum = 0;
//
//	public synchronized void increaseSum() {
//		Thread t = Thread.currentThread();
//		String name = "Thread-" + t.getId();
//		try {
//			Thread.sleep(100);
//			this.sum += 1;
//			System.out.println(name + " sum is: " + sum);
//		} catch (InterruptedException ex) {
//			System.out.println(ex.getMessage());
//		}
//	}
//
//	public static void main(String[] args) throws InterruptedException {
//		ExecutorService executorService = Executors.newFixedThreadPool(100);
//		MySum mySum = new MySum();
//		for (int i = 0; i < 100; i++) {
//			executorService.submit(() -> mySum.increaseSum());
//		}
//		executorService.shutdown();
//		executorService.awaitTermination(60, TimeUnit.SECONDS);
//	}
//}
